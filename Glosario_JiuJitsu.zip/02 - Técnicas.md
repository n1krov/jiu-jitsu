# ⚔️ Glosario – Técnicas (技 Waza)

Clasificación general de las técnicas en el arte del Jiu Jitsu.

## 投げ技 (Nage Waza) – Técnicas de proyección
## 関節技 (Kansetsu Waza) – Técnicas de luxación
## 固技 (Katame Waza) – Técnicas de control
## 逆技 (Gyaku Waza) – Técnicas de contraataque