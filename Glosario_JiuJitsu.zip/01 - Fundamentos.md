# 🥋 Glosario – Fundamentos (基本 Kihon)

Fundamentos esenciales del Jiu Jitsu Tradicional, incluyendo posturas, caídas y movimientos básicos.

## Posturas (構え Kamae)
- **自然体 (Shizentai)** – Postura natural.
- **半身 (Hanmi)** – Postura lateral.
- **脇構え (Wakigamae)** – Postura con brazo extendido.

## Caídas (受身 Ukemi)
- Técnicas de caída segura.

## Movimientos (転身 Tenshin)
- Movimientos de evasión y desplazamiento.