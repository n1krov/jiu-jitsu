# 📘 Glosario – Introducción (紹介 Shōkai)

Términos introductorios y de iniciación en la práctica.

- **道場の礼 (Dōjō no Rei)** – Etiqueta del dojo.
- **基本の姿勢 (Kihon no Shisei)** – Posturas básicas.
- **基本の打撃 (Kihon no Dageki)** – Golpes básicos.