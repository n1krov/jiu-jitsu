# ↔️ Glosario – Direcciones

Términos para orientación espacial y laterales.

- **右 (Migi)** – Derecha.
- **左 (Hidari)** – Izquierda.
- **前 (Mae)** – Frente.
- **後ろ (Ushiro)** – Atrás.
- **内 (Uchi)** – Interno / interior.
- **外 (Soto)** – Externo / exterior.
- **上 (Ue)** – Arriba.
- **下 (Shita)** – Abajo.