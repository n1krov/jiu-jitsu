# 💨 Glosario – 乱取り (Randori)

Práctica libre y fluida, con control.

## Objetivo
Desarrollar reacción, adaptación y aplicación dinámica.

## Puntos Clave
- **流れ (Nagare)** – Fluidez.
- **反応 (Hannō)** – Reacción.
- **制御 (Seigyo)** – Control.