# 🔁 Glosario – Práctica (練習 Renshū)

Tipos de práctica estructurada en Jiu Jitsu.

- **基本の組み手 (Kihon no Kumite)** – Ejercicios básicos en pareja.
- **型 (Kata)** – Formas o secuencias de movimientos.
- **乱取り (Randori)** – Práctica libre.
- **組み手 (Kumite)** – Combate preestablecido o libre.