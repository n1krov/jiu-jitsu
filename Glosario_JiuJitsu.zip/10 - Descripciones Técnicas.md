# 📚 Glosario – Descripciones Técnicas (説明 Setsumei)

Explicaciones detalladas de técnicas específicas.

- **小手返し (Kote Gaeshi)** – Luxación de muñeca.
- **大外落とし (Ōsoto Otoshi)** – Derribo externo.
- **体落とし (Tai Otoshi)** – Proyección del cuerpo.