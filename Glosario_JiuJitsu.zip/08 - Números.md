# 🔢 Glosario – Números (数字 Sūji)

| Número | Kanji | Pronunciación |
|--------|-------|----------------|
| 1      | 一    | Ichi           |
| 2      | 二    | Ni             |
| 3      | 三    | San            |
| 4      | 四    | Shi / Yon      |
| 5      | 五    | Go             |
| 6      | 六    | Roku           |
| 7      | 七    | Shichi / Nana  |
| 8      | 八    | Hachi          |
| 9      | 九    | Kyū / Ku       |
| 10     | 十    | Jū             |