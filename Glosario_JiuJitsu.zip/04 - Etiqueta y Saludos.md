# 🙇 Glosario – Etiqueta y Saludos (礼 Rei)

Normas de cortesía, respeto y saludo en el dojo.

- **道場に入る (Dōjō ni hairu)** – Entrar al dojo.
- **座り方 (Suwarikata)** – Postura de sentarse.
- **立ち礼 (Tachi Rei)** – Saludo de pie.
- **座り礼 (Suwari Rei)** – Saludo sentado.