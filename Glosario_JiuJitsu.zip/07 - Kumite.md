# 🥊 Glosario – 組み手 (Kumite)

Combate libre o preestablecido con enfoque técnico.

## Tipos
- **基本組み手 (Kihon Kumite)** – Combate básico.
- **自由組み手 (Jiyū Kumite)** – Combate libre.

## Puntos Clave
- **間合い (Maai)** – Distancia.
- **タイミング (Taimingu)** – Timing.
- **気 (Ki)** – Enfoque mental.