# 🛡️ Glosario – Defensa Personal (護身術 Goshinjutsu)

Técnicas orientadas a la protección y reacción ante agresiones comunes.

## Golpe frontal
- **正面打ちへの防御 (Shōmen Uchi e no Bōgyo)**

## Agarre de solapa
- **胸倉取りへの対応 (Mune Gurai Dori e no Taiō)**

## Agarre por detrás
- **後ろ取りへの対応 (Ushiro Dori e no Taiō)**